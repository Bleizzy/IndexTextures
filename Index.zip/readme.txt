Models under assets/minecraft/models/block are adapted from Patrix 32x by patrixcraft

it can be found here: https://modrinth.com/resourcepack/patrix-32x

I wouldn't have been able to do it without it so please go and support his work, thank you.